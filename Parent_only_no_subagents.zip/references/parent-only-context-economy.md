# Parent-Only Context Economy

Use this reference when the task is long, the session may be resumed, or the next step could trigger broad rereads. The goal is to keep one parent session efficient without helper agents.

## Core Rule

Do not create a new agent, ask for delegated execution, or replay the full transcript for a clean start. Continue serially with a compact checkpoint unless the current context is unsafe, materially stale, or no longer matches the task boundary.

## Session Ledger

Maintain only decision-changing state:

```text
active_objective:
current_decision:
owned_files:
known_locators:
assumptions:
last_verified:
failed_checks:
open_risks:
next_action:
omitted_context:
```

The ledger is a pointer map, not a summary dump. Prefer paths, symbols, line ranges, commands, and result hashes over prose restatement.

## Context Reuse

Before reading or searching, check whether the answer is already represented by a locator, a recent command result, or a preserved checkpoint. Reopen exact files or line ranges; avoid full repository tours. For repeated command output, keep the command, exit code, failing diagnostic, and final summary, then discard raw noise unless the failure requires more lines.

## Serial Work Queue

When multiple independent tasks exist, order them by dependency and risk. Batch tiny adjacent actions touching the same files. Keep one writable owner: the parent. Avoid interleaving unrelated edits that force repeated context switching. Complete, verify, and checkpoint one coherent slice before moving to the next.

## Checkpoint Instead Of Restart

Checkpoint before long pauses, scope changes, risky edits, or context compaction:

```text
checkpoint_reason:
completed:
changed_files:
evidence_locators:
tests_run:
current_failure:
next_safe_step:
do_not_reload:
```

A checkpoint should make the next continuation possible without transcript replay. If a fresh pass is unavoidable, start from the checkpoint and exact locators, not from all prior discussion.

## Review Without Delegation

For self-review, switch mode instead of spawning another reviewer. Review from acceptance criteria, diff stats, changed files, tests, and high-risk paths. Use a second narrow pass over only risky hunks. Mark uncertainty explicitly when independent review would materially improve confidence but is unavailable in this bundle.

## When To Expand

Expand context only when one of these is true: the current decision cannot be made from locators, a verification failure points outside known files, the user changed the objective, a safety/legal/source-fidelity question is active, or the artifact must be packaged/released and manifest completeness must be checked.

## Waste Signals

- repeated full file trees without a new routing decision
- reading whole files when a symbol or line range is enough
- long explanations before the success condition is known
- restarting the session to avoid making a checkpoint
- quoting raw logs instead of sliced diagnostics
- reviewing unrelated files because they are nearby
- reporting every command when only failures matter

Corrective action is not silence; it is a smaller locator, a checkpoint, a specific verification command, or a narrower final report.
