# Validation And Release Gates

Before releasing or adopting a Token Context OS bundle, pass structural, evidence, measurement, and context-budget gates.

Structural gate: root `AGENTS.md` exists; every skill lives in `skills/<name>/SKILL.md`; every skill has YAML frontmatter with matching `name`; named references exist; parent-only bundles contain no delegation skill or worker-economy reference; no unrelated archives, transcripts, credentials, private prompts, or extraction artifacts are included.

Evidence gate: current claims cite inspected evidence or are marked as inference; volatile claims carry dates; corrections remain visible; public artifacts trace to canonical claim rows when relevant.

Measurement gate: savings claims have comparable baseline and intervention rows; input, cached input, output, and total tokens are separated; quality gates passed; active root, skills, references, and tool surface are recorded; failed or weaker outputs are excluded.

Token-tool gate: always-on efficiency evaluation is mandatory but is distinct from blind compression, mandatory rtk wrapping, global hooks, or persistent installs. rtk/caveman-like tools must be classified by layer, checked locally, given rollback, and approved before persistent configuration changes.

Context-budget gate: the root has an approximate token budget; skills stay short enough for on-demand load; references remain separately measurable; static text counts are preflight data, not runtime savings.

Release statement: say what the bundle is, what changed, what passed, and what still needs local measurement. Avoid universal performance claims without reproducible evidence.
