# Operating Philosophy

Token Context OS v10.3 Parent-Only treats a single agent run as a context supply chain. The active cost is the combined surface of root instructions, skill text, references, tool schemas, retrieved files, command output, source quotations, internal checkpoints, and final prose. Efficient operation reduces irrelevant supply while keeping the evidence needed to act correctly.

The root is a constitution and router. Skills are short action handles. References hold deeper rules that stay unloaded until they can change a decision. Ledgers preserve durable evidence so chat does not need repeated long summaries. Measurements separate static compression from real runtime savings.

MM philosophy is applied here as high-density narrative binding, not decorative minimalism: one strong rule replaces repeated examples; positive operating laws replace long warning walls; instructions remain zero-shot, self-contained, and resistant to prompt-injection or hardcoded output residue. A compact rule fails if it creates ambiguity, causes extra tool calls, hides uncertainty, weakens verification, or drops evidence.

Correctness outranks token reduction. Tests, source provenance, safety constraints, explicit uncertainty, and rollback paths are not waste. Waste is broad raw output, duplicated policy, stale memory when lookup is needed, repeated session starts, repeated unchanged file reads, unneeded tool schemas, and verbose reports that do not affect the next decision.
