# Token Efficiency Playbook

Run efficiency evaluation before broad context loading on every task, resumed session, and substantial follow-up. The usual savings order is route, locate, slice, expand only by reason, preserve evidence rows, avoid session churn, and measure comparable runs.

## Relevance Gate

Before loading context, answer: what decision will this change, what smaller locator can answer first, what evidence must survive if the context is discarded, and what quality gate could fail if omitted. If no answer is clear, search or inspect a narrower slice.

## Slicing Patterns

Logs: command, exit code, first failing diagnostic, final summary, nearby lines. Diffs: changed files, public API changes, risky hunks, tests. Source: imports, exported symbols, target implementation, callers, relevant tests. JSON: schema keys, counts, anomalies, selected rows. Search: exact matches with paths, line numbers, and minimal surrounding context.

## Cache And Context

Prompt caching can reduce cost or latency when stable prefixes repeat, but cached tokens still crowd the working window and can hide irrelevant policy. Track cached input separately from context minimization.

## Session Churn Control

Parent-only operation has no helper-agent startup cost, but it can still waste quota through restart loops, repeated repository tours, full-rule restatement, broad command output, and re-reading unchanged files. Prefer: keep a compact session ledger, carry locator rows forward, use delta notes, checkpoint before context reset, and resume from the checkpoint instead of replaying the transcript.

Continuation delta:

```text
objective_delta:
decision_needed:
known_locators:
changed_files:
last_verified:
open_risks:
next_small_action:
```

Restart only when the current context is contaminated, the repository state changed materially, or the task boundary changed enough that continuing would be riskier than a checkpointed fresh pass. Never restart merely for cosmetic neatness.

## rtk And caveman

rtk-style tools belong to command-output filtering. caveman-style tools belong to assistant-output compression. Treat both as governed interventions, not blind transformations. Use them only when they preserve the decision-critical evidence and have a raw-output or full-output recovery path.

## Savings Formula

For comparable runs:

```text
input_delta_pct = (baseline_input - intervention_input) / baseline_input * 100
total_delta_pct = (baseline_total - intervention_total) / baseline_total * 100
```

Report the quality gate beside any delta. A failed test, missing citation, weaker review, or hidden uncertainty invalidates the savings claim.
