# Baseline V3 Contract

Baseline v3 records token usage and quality outcomes without storing raw private prompts. It answers whether a specific intervention reduced tokens for a comparable task while preserving quality.

Required row:

```text
run_id:
timestamp_local:
timestamp_utc:
timezone:
task_class:
task_fingerprint:
repository_or_dataset:
model:
runtime:
tool_surface:
active_root_contract:
active_skills:
active_references:
intervention_label:
input_tokens:
cached_input_tokens:
output_tokens:
total_tokens:
session_restart_count:
broad_context_reload_count:
repeated_file_read_count:
discarded_context_work:
checkpoint_count:
report_output_tokens:
quality_gate:
quality_result:
failure_or_regression:
notes:
```

Compare only when task class, model family, repository state, tool surface, and required quality gates are comparable. A shorter answer with weaker tests, fewer citations, missing review depth, or lower correctness is not a savings win. Cached tokens affect cost and latency interpretation but do not prove context was removed. Session-economy fields separate real context reduction from cache effects; do not attribute savings to a prompt rewrite when the dominant change is fewer restarts, narrower locators, lower effort, shorter reports, or better command slicing.
