---
name: baseline-observer
description: Use when measuring token usage, preparing comparable baseline rows, evaluating a prompt/tool intervention, session churn, or any efficiency/savings claim.
---

# Baseline Observer

No numerical savings claim is valid without comparable baseline and intervention rows plus a passed quality gate. Record environment, model, runtime, tool surface, active root, active skills/references, intervention label, token fields, session-economy fields, and outcome without storing private raw prompt text.

Minimum row: run id, local/UTC timestamp, task class, fingerprint, model, runtime, tool surface, intervention label, input tokens, cached input tokens, output tokens, total tokens, session restart count, broad context reload count, repeated file read count, discarded context work, checkpoint count, report output tokens when available, quality gate/result, failure/regression, notes.

Compare like with like. Prompt caching affects cost and latency but does not prove context was smaller. Session churn is measured separately from model choice: record whether savings came from fewer restarts, narrower locators, better cache reuse, lower model rate, lower effort, sliced command output, or reduced report output.

Load `references/baseline-v3-contract.md` before creating or changing baseline records.
