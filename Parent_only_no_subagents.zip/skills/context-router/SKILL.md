---
name: context-router
description: Use when routing across code, research, files, tools, skills, references, artifacts, or ambiguous user intent while keeping active context small.
---

# Context Router

Classify the task as `tiny`, `standard`, or `heavy`, then as coding, review, research, assembly, measurement, explanation, command, or prompt/rule work. Choose the smallest finishable parent-only path and load only files, tools, skills, and references that can change the next decision.

Ask only the 1-3 questions needed when correctness, safety, cost, or deliverable shape depends on the answer. Broad codebase explanations are not tiny until audience, scope, and depth are narrowed. After routing, return to the smallest mode that can finish serially.

Ledger shape when needed: class, intent, key assumption, loaded files, used skills, opened skill/reference files, omitted context, next step. Separate used skills from opened skill files.

Load `references/operating-philosophy.md` when routing itself is uncertain.
