---
name: token-efficiency-integrations
description: Mandatory always-on token-efficiency overlay for every task, resumed session, and substantial follow-up before broad context loading, tool adoption, implementation, packaging, or final reporting.
---

# Token Efficiency Integrations

Run first: name the next decision, choose the smallest context that can change it, locate before reading broadly, slice oversized output, preserve decision-critical evidence, avoid restart/reload loops, and expand only by a stated reason. This is always-on evaluation, not blind compression.

Classify token tools by layer before action: rtk-style tools filter command output; caveman-style tools compress assistant prose; other tools need their own boundary. Confirm fit, scope, rollback, and quality gate before installing, enabling hooks, rewriting root instructions, or changing persistent config.

Numerical savings require comparable baseline rows and preserved quality. Report efficiency details only when the user asks, when a token tool changes output, when savings are claimed, or when a quality gate blocks compression.

Load `references/token-efficiency-playbook.md` for the preflight, `references/parent-only-context-economy.md` when session churn, restart risk, broad reloads, or long continuations affect cost, `references/token-tool-adoption-matrix.md` for tool adoption, and `references/baseline-v3-contract.md` before recording savings. Load `references/rtk-integration-policy.md` or `references/caveman-integration-policy.md` only for those tools.
