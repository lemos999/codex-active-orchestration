# Graph Locator Policy

Graph locators, dependency maps, call graphs, semantic indexes, and Graphify-style tools reduce candidate count; they do not become evidence by themselves. Their output points to original files, tests, commits, documents, or sources that still need confirmation.

Record tool name, package name if relevant, version or index date, query, returned candidates, confirmed original sources, false positives, and decision. Confirm code claims against symbol definitions, callers, tests, and configuration. Confirm research claims against primary documentation or releases. Treat generated natural-language graph summaries as hypotheses until original sources support them.
