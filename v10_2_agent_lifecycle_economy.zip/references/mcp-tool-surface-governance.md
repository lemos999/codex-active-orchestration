# MCP And Tool Surface Governance

Tool schemas are context. A broad tool surface can raise hidden instruction load, invite accidental calls, and return oversized output. Keep tools aligned with the active task.

Use a tool only when it answers a concrete question or performs a required action. Prefer local search for local files, official APIs for structured remote data, and direct repository tools for GitHub metadata. Ask tools for the smallest useful result: metadata, filenames, line windows, status summaries, counts, or top candidates. Expand only the candidate that matters.

Governance record:

```text
task_class:
tool_family_used:
reason:
expected_output_size:
actual_output_size:
slice_applied:
omitted_tool_family:
omission_reason:
```

A zero-call tool family is acceptable when it would not change the decision.
