# caveman Integration Policy

caveman-style tooling compresses assistant prose. Its role is shorter status, review, or summary output when brevity preserves the task's evidence and quality obligations.

Known v9 evidence from 2026-05-13 Asia/Seoul: local inspection found `JuliusBrussee/caveman` at commit `63a91ecadbf4c4719a4602a5abb00883f9966034`, branch `main`, tag `v1.8.2`. `node bin/install.js --dry-run --only codex` showed a Codex install route. Some native Windows/sandbox tests were not fully green. Treat this as an available route, not unconditional adoption proof.

Use compression for low-risk summaries, repeated status, compact code-review comments, and user-approved compact mode. Preserve file paths, commands, errors, versions, dates, citations, test results, assumptions, risks, and unresolved questions. Avoid compressed style for security-sensitive, legal, medical, financial, citation-heavy, release, audit, or ambiguous work unless the user explicitly accepts that style and all required fields remain.

Prefer session-scoped or dry-run enablement before global install. Do not modify persistent agent configuration, root instructions, or profiles without explicit approval. Verify by comparing normal and compressed output for completeness when making savings claims. Rollback is to stop compressed mode and restore prior prompt or config from backup/diff.
