# Token Tool Adoption Matrix

Always-on efficiency evaluation is mandatory. Token tools are optional interventions that change a specific layer of the context supply chain and require a target, gate, and rollback path.

| Tool class | Layer | Benefit | Risk | Gate |
|---|---|---|---|---|
| rtk-style CLI proxy | command output | smaller logs, diffs, status, tests | hidden diagnostics | command smoke test plus raw-output recovery |
| caveman-style compressor | assistant prose | shorter replies | lost nuance, evidence, citations | completeness check |
| compact root/skill rewrite | instruction surface | lower baseline input | lost authority or safety | structural gate plus behavior review |
| MCP/tool schema reducer | tool surface | smaller tool descriptions | malformed tools or lost affordances | tool-call smoke test |

Adoption flow: name the tool and scope, classify the layer, inspect trust and rollback boundaries, prefer workspace-local dry-runs, record a baseline row for numerical claims, enable only after the gate is named, verify with one representative task, and record limitations.

Hard boundaries: no blind compression, hidden evidence loss, global installs, broad hooks, telemetry opt-in, elevated binaries, or persistent user-profile writes without explicit approval for that target.
