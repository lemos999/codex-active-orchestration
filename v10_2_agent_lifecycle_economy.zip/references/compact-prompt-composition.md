# Compact Prompt Composition

Compact prompt composition writes instructions that are shorter because they are routed and semantically dense, not because they omit obligations. The always-on layer carries authority, classification, safety, context discipline, and final expectations. Skills carry action procedures. References carry deeper rubrics, schemas, examples, and validation details.

Apply MM when revising prompts or operating rules: flatten repeated scaffolding into dense prose, bind required output shapes descriptively, use positive operating laws, preserve zero-shot self-sufficiency, remove hardcoded recurrent output residue, and test compression equivalence. Keep YAML frontmatter, reference names, field contracts, and small code blocks when they improve machine routing or auditability.

Good compression replaces repeated examples with a generative rule, decorative warnings with observable checks, and raw context dumps with locators plus expansion criteria. Bad compression hides uncertainty, removes evidence, blurs authority, weakens acceptance criteria, or forces extra turns.

Quality test: a new agent can identify when to use it, required outputs remain explicit, safety and evidence obligations remain visible, the root is smaller or more routable, and no hidden private examples are required.
