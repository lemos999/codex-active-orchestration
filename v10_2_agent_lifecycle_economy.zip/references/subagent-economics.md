# Subagent Economics

Subagents are useful when they isolate context, run safely in parallel, keep a narrow subsystem warm, or own disjoint work. They are not automatically cheaper: each worker pays startup instructions, model-selection brief, source reads, tool output, report tokens, and parent integration.

Use delegation for independent code areas, parallel evidence checks, verification that can run while the parent works, or bounded exploration with a concrete question. Avoid delegation for the immediate critical-path blocker, vague repository tours, duplicate broad inspection, tasks requiring continuous parent judgment, theatrical thoroughness, or tiny follow-ups that could reuse an existing worker or be done directly.

Model economy: keep selection current, not model-pinned. The parent is the user/runtime model; a user-specified worker model wins unless unavailable or unsafe. If omitted, run one compact session cost preflight: classify task, list available worker models, check official Codex/API pricing, included-limit guidance, Fast/speed multipliers, and visible account/promo limits, estimate `(fresh input × input rate) + (cached input × cached rate) + ((visible output + reasoning output) × output rate)` with effort/speed multipliers, then choose the cheapest adequate model that supports required tools, context, and quality. Cache the timestamped snapshot; refresh only when stale or economics changed. If lookup is unavailable, pick the smallest adequate available worker and mark it provisional.

Lifecycle economy: a warm adequate worker can beat a cheaper cold worker. Before spawning, check whether an existing worker already owns the same subsystem, file set, evidence corpus, or validation path. Continue that worker with a delta-only brief when scope and trust boundary match. Spawn cold only when parallel value or isolation outweighs startup cost. Terminate when scope is complete, stale, contaminated, idle, or parent/direct action is cheaper. Keep worker count bounded; one warm precise worker often beats many broad cold workers.

Cold-start estimate includes: always-on instructions, selected skill/reference reads, model-selection text, repo/file discovery, duplicated logs, repeated source snippets, and final report. Reuse estimate includes only the new decision, changed files, delta locators, validation target, and short return contract. If reuse would require replaying a long transcript, make a checkpoint and restart from the checkpoint instead.

Worker report contract:

```text
finding:
evidence_locator:
files_changed:
verification:
risk:
open_question:
next_delta:
```

The parent integrates by evidence. Missing locators, missing validation, unclear file ownership, or missing next-delta make the report weak.
