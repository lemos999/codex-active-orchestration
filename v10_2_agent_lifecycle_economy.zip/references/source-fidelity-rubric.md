# Source Fidelity Rubric

Use the strongest practical source for each claim.

Tier 1: official documentation, standards, repository source, release notes, primary papers, direct datasets, legal/regulatory text, and first-party announcements. Tier 2: maintainer comments, issue discussions, benchmark repositories, conference material, and reproducible technical blogs. Tier 3: news, summaries, forums, social posts, tutorials, and aggregators. Tier 4: memory, uncited model knowledge, hearsay, and unsupported inference.

Claim status:

```text
verified: directly supported by inspected evidence
inferred: reasonable synthesis from evidence
disputed: sources conflict or interpretation is contested
stale-risk: could have changed since inspection
unsupported: not enough evidence to rely on
```

High-impact or current claims need Tier 1 when practical or a visible limitation. If a conclusion changes, record old claim, new claim, evidence, date, and affected artifact instead of silently erasing the prior state.
