# Coding Operating Structure

Efficient coding agents find the owner of the requested behavior, change the smallest coherent surface, and verify the highest-risk path. The loop is:

```text
understand -> locate -> inspect -> scope -> patch -> verify -> repair -> report
```

Understand the behavior and success signal. Locate with cheap signals: file lists, `rg`, tests, routes, symbols, manifests, errors, and graph candidates. Inspect only owner slices, interfaces, callers, tests, config, and local conventions. Expand by a named reason such as caller depth, fixture path, config path, or runtime entry point.

Scope writes narrowly. Preserve user edits and local style. Avoid unrelated cleanup and new dependencies unless they reduce real risk. Patch in repository style; comments explain non-obvious choices only. Verify with the cheapest meaningful check: targeted test, typecheck, touched-file lint, build, or focused manual check. Repair observed failures, rerun the relevant check, then stop when the success condition is met. Report files changed, behavior, verification command/outcome, and remaining risk without raw logs unless requested.
