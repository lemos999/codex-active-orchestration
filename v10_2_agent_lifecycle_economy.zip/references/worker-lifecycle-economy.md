# Worker Lifecycle Economy

Agent churn is a quota risk. A cold worker usually pays startup instructions, model-selection brief, repository orientation, repeated file reads, duplicated tool output, and final report tokens before it produces value. Treat worker creation as a leased resource, not a disposable message.

## Spawn Gate

Before spawning, answer in one compact note:

```text
decision:
existing_warm_worker:
owned_scope:
startup_cost_risk:
expected_parallel_value:
cheapest_sufficient_model:
stop_or_reuse_condition:
```

Spawn only when the task is independent, bounded, not already owned by a warm worker, and cheaper or safer than parent expansion. Do not spawn for a tiny one-file check, a single command result, a vague repository tour, or a task whose answer depends on continuous parent judgment. Prefer parent direct action or reuse of an existing worker when startup context would dominate.

## Warm Worker Reuse

Keep a compact ledger while workers exist:

```text
worker_id:
model_effort:
owned_scope:
file_locks:
warm_context:
last_validated_state:
current_assignment:
risk:
lease_expires_when:
next_delta:
```

Reuse a worker when the next task shares the same file set, subsystem, evidence corpus, trust boundary, and model/effort class. Continue with a delta brief; do not resend full rules, full file lists, broad logs, or old transcripts.

Delta brief shape:

```text
continue_from:
new_decision:
reuse_context:
changed_since_last:
allowed_files:
forbidden_files:
return_only:
```

## Context Checkpointing

Every worker report must leave enough evidence for restart without transcript replay: touched files, locators, test commands, failure signatures, assumptions, and the next safe delta. The parent stores the checkpoint and uses it instead of pasting prior chat. If a worker must be replaced, brief the replacement from the checkpoint, not from the full conversation.

## Lease And Stop Rules

Keep a worker alive only while it is actively useful. End or replace it when the scope is complete, the worker read too broadly, the context became stale or contaminated, the model is no longer economically adequate, the task crosses a trust boundary, a file lock conflicts, or parent/direct action becomes cheaper. Do not preserve workers merely because they exist.

## File Ownership

One writable owner per file set. The parent keeps locks. Workers may inspect shared files, but only one worker edits a locked path. If two workers need the same file, serialize through the parent or merge after both provide locator-only evidence.

## Measurement

When evaluating delegation, separate:

- cold-start input
- reused cached input
- fresh source reads
- output/reasoning tokens
- discarded worker work
- parent integration tokens

A cheaper model can still be wasteful if churn causes repeated startup. A warmer worker can be cheaper even when its model is slightly more expensive, provided the scope and safety boundary still fit.
