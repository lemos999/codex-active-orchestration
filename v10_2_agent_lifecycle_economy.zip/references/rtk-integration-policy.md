# rtk Integration Policy

rtk is a command-output filtering proxy. Its role is to reduce oversized shell output before the agent sees it, not to replace source inspection, tests, or evidence ledgers.

Known v9 evidence from 2026-05-13 Asia/Seoul: local inspection found `rtk-ai/rtk` at commit `55f998d08cd80ece970fe5e61eaae3533512288b`, branch `develop`, tag `dev-0.40.0-rc.215`. Rust tests were not run. A Windows `rtk 0.39.0` binary ran version/help and several workspace-scoped commands; native Windows `rtk ls` failed when `ls` was absent. Treat this as limited viability evidence, not universal savings proof.

Use rtk when the task depends on large command output: listings, git status/diffs, dependency lists, builds/tests, searches, logs, or structured CLI output. Prefer raw commands when output is already small, exact bytes matter, diagnostics are subtle, or filtering could hide the failure. Keep a raw-output recovery path. Prefer explicit workspace-scoped calls before global init. Do not write global agent config, user profiles, telemetry opt-ins, or hooks without explicit approval.

Verification: compare raw and filtered output on one representative command class. Numerical savings require baseline-v3 rows and a passed quality gate. Rollback is returning to raw commands, removing rtk-specific instructions/hooks, and deleting workspace-scoped tracking files if requested.
