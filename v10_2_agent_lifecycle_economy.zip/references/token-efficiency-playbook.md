# Token Efficiency Playbook

Run efficiency evaluation before broad context loading on every task, resumed session, and substantial follow-up. The usual savings order is route, locate, slice, expand only by reason, preserve evidence rows, and measure comparable runs.

## Relevance Gate

Before loading context, answer: what decision will this change, what smaller locator can answer first, what evidence must survive if the context is discarded, and what quality gate could fail if omitted. If no answer is clear, search or inspect a narrower slice.

## Slicing Patterns

Logs: command, exit code, first failing diagnostic, final summary, nearby lines. Diffs: changed files, public API changes, risky hunks, tests. Source: imports, exported symbols, target implementation, callers, relevant tests. JSON: schema keys, counts, anomalies, selected rows. Search: exact matches with paths, line numbers, and minimal surrounding context.

## Cache And Context

Prompt caching can reduce cost or latency when stable prefixes repeat, but cached tokens still crowd the working window and can hide irrelevant policy. Track cached input separately from context minimization.


## Agent Churn Control

Treat every new worker as fresh input unless proven otherwise. Prefer: reuse warm worker, send delta brief, checkpoint evidence, then spawn cold only when necessary. Do not keep respawning agents over the same files; repeated cold reads can erase the savings from a cheaper model. Track `cold_start_input`, `reused_context`, `discarded_worker_work`, and `parent_integration` when comparing runs.

Reusable worker delta:

```text
same_scope?
same_trust_boundary?
same_file_locks?
new_decision_only?
short_return_contract?
```

If any answer is no, checkpoint and either parent-direct the work or spawn a new bounded worker from the checkpoint instead of replaying the transcript.

## rtk And caveman

rtk-style tools belong to command-output filtering. caveman-style tools belong to assistant-output compression. Treat both as governed interventions, not blind transformations. Use them only when they preserve the decision-critical evidence and have a raw-output or full-output recovery path.

## Savings Formula

For comparable runs:

```text
input_delta_pct = (baseline_input - intervention_input) / baseline_input * 100
total_delta_pct = (baseline_total - intervention_total) / baseline_total * 100
```

Report the quality gate beside any delta. A failed test, missing citation, weaker review, or hidden uncertainty invalidates the savings claim.
