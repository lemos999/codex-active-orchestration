---
name: evidence-ledger
description: Use when claims, sources, gaps, corrections, or durable research/artifact state must be recorded without carrying raw transcripts forward.
---

# Evidence Ledger

Record compact claim rows instead of full source dumps.

```text
claim:
status: verified | inferred | disputed | stale-risk | unsupported
evidence:
source_type:
source_date:
access_date:
locator:
confidence:
gap_or_correction:
```

Separate direct evidence, synthesis, inference, and unresolved uncertainty. Add correction rows when conclusions change; do not silently replace downstream-relevant claims. For public artifacts, cite the canonical row rather than a transient chat summary.

Load `references/source-fidelity-rubric.md`; load `references/validation-and-release-gates.md` before publishing a bundle or report.
