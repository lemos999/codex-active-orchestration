---
name: source-fidelity
description: Use when facts may be stale, contested, high-impact, niche, unfamiliar, citation-sensitive, or when the user requests links, quotes, or current status.
---

# Source Fidelity

Prefer primary sources: official documentation, release notes, standards, repository files, papers, direct datasets, or first-party announcements. Use secondary sources for orientation unless the task is about commentary or public reaction. Verify current facts when they could plausibly have changed.

For important claims, mark whether they are verified, inferred, disputed, stale-risk, or unsupported. Use concrete dates. Summarize instead of quoting at length. If sources disagree, compare authority, scope, date, and evidence rather than averaging.

When research changes implementation or artifacts, write the stable conclusion into an evidence row. Load `references/source-fidelity-rubric.md` and, before release, `references/validation-and-release-gates.md`.
