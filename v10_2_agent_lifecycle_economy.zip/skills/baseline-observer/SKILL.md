---
name: baseline-observer
description: Use when measuring token usage, preparing comparable baseline rows, evaluating an intervention, worker reuse, or any efficiency/savings claim.
---

# Baseline Observer

No numerical savings claim is valid without comparable baseline and intervention rows plus a passed quality gate. Record environment, model, runtime, tool surface, active root, active skills/references, intervention label, token fields, worker lifecycle fields, and outcome without storing private raw prompt text.

Minimum row: run id, local/UTC timestamp, task class, fingerprint, model, runtime, tool surface, intervention label, input tokens, cached input tokens, output tokens, total tokens, cold worker count, reused worker count, discarded worker work, parent integration tokens when available, quality gate/result, failure/regression, notes.

Compare like with like. Prompt caching affects cost and latency but does not prove context was smaller. Worker reuse is measured separately from cheap-model selection: record whether savings came from fewer cold starts, narrower locators, better cache reuse, lower model rate, lower effort, or reduced report output.

Load `references/baseline-v3-contract.md` before creating or changing baseline records.
