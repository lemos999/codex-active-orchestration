---
name: subagent-gate
description: Use when considering delegation, parallel workers, worker isolation, worker model choice, worker reuse, or subagent report integration.
---

# Subagent Gate

Delegate only when work is bounded, independently useful, and cheaper or safer than parent-only context expansion. Do not fan out vague exploration, duplicate broad reads, or churn workers for tiny follow-ups.

Before spawning, check the warm-worker ledger. Reuse an existing worker when model, trust boundary, scope, and file ownership match; send a delta brief instead of full context. Spawn cold only when no warm worker fits and startup cost is justified by independent value. Keep one writable owner per file set.

Brief shape:

```text
objective:
owned_scope:
excluded_scope:
allowed_changes:
required_output:
evidence_required:
validation:
reuse_or_stop_condition:
maximum_report_shape:
```

Delta continuation shape:

```text
continue_from:
new_decision:
reuse_context:
changed_since_last:
allowed_files:
forbidden_files:
return_only:
```

Prefer cheap worker models and low/medium effort for locate, slice, verify, and narrow edits; escalate only when the worker owns hard reasoning. Reports stay short: findings, touched files, evidence locators, verification, risks, open questions, next delta. The parent keeps final acceptance, file locks, and lifecycle decisions.

Load `references/subagent-economics.md` and `references/worker-lifecycle-economy.md` before launching, reusing, terminating, or integrating workers.
