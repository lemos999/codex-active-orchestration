---
name: graph-locator-boundary
description: Use when graph indexes, dependency maps, call graphs, Graphify-style systems, semantic locators, or similar tools narrow context.
---

# Graph Locator Boundary

Graph output is a locator, not authority. Record tool, version/index date, query, candidates, confirmed sources, false positives/gaps, and decision. Open the smallest original source slice needed to verify symbol definitions, callers, tests, config, or source claims.

Load `references/graph-locator-policy.md` for provenance and failure modes.
