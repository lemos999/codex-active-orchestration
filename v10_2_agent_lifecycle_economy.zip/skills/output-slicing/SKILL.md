---
name: output-slicing
description: Use when command output, logs, diffs, JSON, search results, or source files are too large to load or paste whole.
---

# Output Slicing

Define the question the output must answer, then keep only the slice that can answer it.

Use error slices for first failing command, exit code, diagnostic, and nearby lines; diff slices for changed files, hunk headers, public API changes, risky hunks, and tests; search slices for exact matches with paths and line numbers; JSON slices for schema keys, counts, anomalies, and selected rows; source slices for imports, public interfaces, target function, callers, and tests.

Preserve enough context to avoid false interpretation. If insufficient, expand by one named criterion instead of dumping everything. Load `references/token-efficiency-playbook.md` for patterns and `references/mcp-tool-surface-governance.md` when tool output shape is the bloat source.
