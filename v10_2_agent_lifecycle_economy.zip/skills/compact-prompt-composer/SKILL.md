---
name: compact-prompt-composer
description: Use when creating or revising agent instructions, skill files, prompt contracts, operating manuals, or context-minimized workflow prose.
---

# Compact Prompt Composer

Write dense, direct operating prose with explicit authority, triggers, actions, output contracts, safety boundaries, evidence duties, and verification gates. Keep the always-on root small; route detail into skills and references.

Apply MM: flatten repeated scaffolding, bind output shapes descriptively, use positive operating laws, preserve zero-shot behavior, avoid hardcoded recurrent output residue, and test compression equivalence. Keep field contracts, YAML, and small code blocks when they improve execution.

Do not compress away uncertainty, evidence, acceptance criteria, user tone, or safety constraints. Load `references/compact-prompt-composition.md` and `references/mm-efficiency-profile.md` for prompt/rule revisions.
