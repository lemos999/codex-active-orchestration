---
name: coding-operation-loop
description: Use when implementing, repairing, refactoring, testing, reviewing for fixes, setup, or executing approved coding work with minimal context waste.
---

# Coding Operation Loop

Follow the narrow loop:

```text
understand -> locate -> inspect -> scope -> patch -> verify -> repair -> report
```

Understand behavior and success signal. Locate owners through cheap signals before broad reads. Inspect only relevant interfaces, implementations, callers, tests, config, and local conventions. Scope writes to the smallest coherent surface. Patch in style. Verify with the cheapest meaningful check. Repair observed failures or proven omissions, rerun the relevant check, and stop when the condition is met.

For tiny work, keep planning implicit and reports brief. For broad or risky work, load `references/coding-operating-structure.md`. Use `output-slicing` for large command output, `source-fidelity` for current external behavior, `baseline-observer` for savings claims, and `subagent-gate` only when independent worker scope is real.
